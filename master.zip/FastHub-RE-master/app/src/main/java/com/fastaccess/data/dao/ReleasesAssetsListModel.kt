package com.fastaccess.data.dao

/**
 * Created by Kosh on 31 Dec 2016, 1:28 PM
 */
class ReleasesAssetsListModel : ArrayList<ReleasesAssetsModel>()