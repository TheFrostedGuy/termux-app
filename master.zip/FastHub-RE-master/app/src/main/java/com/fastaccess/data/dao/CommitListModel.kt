package com.fastaccess.data.dao

import com.fastaccess.data.entity.Commit

/**
 * Created by Kosh on 12 Feb 2017, 12:10 AM
 */
class CommitListModel : ArrayList<Commit>()
