package com.fastaccess.data.dao

import android.net.Uri

/**
 * Created by kosh on 23/07/2017.
 */
class NotificationSoundModel(val name: String? = null, val uri: Uri? = null, val isSelected: Boolean = false)