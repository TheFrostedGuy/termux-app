package com.fastaccess.data.dao

/**
 * Created by Kosh on 09 May 2017, 7:52 PM
 */
class TopicsModel : ArrayList<String>()