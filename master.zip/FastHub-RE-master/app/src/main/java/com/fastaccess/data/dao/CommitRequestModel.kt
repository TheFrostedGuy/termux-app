package com.fastaccess.data.dao

/**
 * Created by kosh on 31/08/2017.
 */
class CommitRequestModel(
    var message: String,
    var content: String?,
    var sha: String,
    var branch: String
)