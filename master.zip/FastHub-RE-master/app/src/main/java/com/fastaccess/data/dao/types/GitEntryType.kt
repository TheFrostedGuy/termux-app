package com.fastaccess.data.dao.types

enum class GitEntryType {
    commit, tree, blob
}