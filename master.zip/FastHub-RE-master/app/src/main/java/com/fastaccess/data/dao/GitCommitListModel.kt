package com.fastaccess.data.dao

/**
 * Created by Kosh on 12 Feb 2017, 12:14 AM
 */
class GitCommitListModel : ArrayList<GitCommitModel?>()