package com.fastaccess.exception

import java.io.IOException

class AuthNullOrBlankException: IOException() {}