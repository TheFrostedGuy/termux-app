package com.fastaccess.data.dao

/**
 * Created by Kosh on 18 Feb 2017, 2:10 PM
 */
class GistHubErrorsModel {
    var resource: String? = null
    var field: String? = null
    var code: String? = null
}