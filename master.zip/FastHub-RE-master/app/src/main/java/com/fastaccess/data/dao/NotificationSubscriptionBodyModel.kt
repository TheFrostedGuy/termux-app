package com.fastaccess.data.dao

/**
 * Created by Hashemsergani on 14.10.17.
 */
class NotificationSubscriptionBodyModel(var subscribed: Boolean, var ignored: Boolean)