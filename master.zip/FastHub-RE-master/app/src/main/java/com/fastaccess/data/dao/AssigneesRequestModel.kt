package com.fastaccess.data.dao

/**
 * Created by Kosh on 05 Mar 2017, 12:01 PM
 */
class AssigneesRequestModel {
    var assignees: List<String>? = null
    var reviewers: List<String>? = null
}