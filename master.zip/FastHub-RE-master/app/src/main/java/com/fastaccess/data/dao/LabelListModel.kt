package com.fastaccess.data.dao

/**
 * Created by Kosh on 12 Feb 2017, 1:32 PM
 */
class LabelListModel : ArrayList<LabelModel>()