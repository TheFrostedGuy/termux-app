package com.fastaccess.data.dao

import java.io.Serializable

/**
 * Created by Kosh on 10 Feb 2017, 9:46 PM
 */
class GithubFileModel : HashMap<String, FilesListModel>(), Serializable