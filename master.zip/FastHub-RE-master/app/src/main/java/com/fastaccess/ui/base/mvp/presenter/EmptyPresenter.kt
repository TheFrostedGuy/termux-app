package com.fastaccess.ui.base.mvp.presenter

import com.fastaccess.ui.base.mvp.BaseMvp

class EmptyPresenter: BasePresenter<BaseMvp.FAView>()
