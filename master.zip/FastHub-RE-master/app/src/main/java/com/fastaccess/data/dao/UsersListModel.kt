package com.fastaccess.data.dao

import com.fastaccess.data.entity.User

/**
 * Created by Kosh on 12 Feb 2017, 1:33 PM
 */
class UsersListModel : ArrayList<User>()
